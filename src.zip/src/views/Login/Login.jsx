import React from 'react';

const Login = () => {
  return (
    <>
      <div className='flex items-center justify-center h-screen bg-WhiteSmoke'>
        <div className="w-96 p-6 shadow-lg bg-WhiteSmoke rounded-md border-solid border border-Red">
            
        </div>
      </div>
    </>
  )
}

export default Login;