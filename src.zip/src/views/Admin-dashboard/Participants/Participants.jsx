import React from 'react'

const Participants = () => {
  return (
    <div>Participants</div>
  )
}

export default Participants;